<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">DataTables pengaduan</h6>
    </div>
    <div class="card-body" style="font-size: 14px">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tgl Pengaduan</th>
                        <th>NIK</th>
                        <th>Isi Laporan</th>
                        <th>Tanggapan</th>
                        <th>Foto</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Tgl Pengaduan</th>
                        <th>NIK</th>
                        <th>Isi Laporan</th>
                        <th>Tanggapan</th>
                        <th>Foto</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>
<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM pengaduan, tanggapan WHERE tanggapan.id_pengaduan='$id' AND tanggapan.id_pengaduan=pengaduan.id_pengaduan";
} else {
    // Handle case when id is not provided.
    $sql = "SELECT * FROM pengaduan, tanggapan WHERE tanggapan.id_pengaduan=pengaduan.id_pengaduan";
}

$query = mysqli_query($koneksi, $sql);
$no = 1;
while ($data = mysqli_fetch_array($query)) { ?>
    <tr>
        <td><?= $no++; ?></td>
        <td><?= $data['Tgl_pengaduan']; ?></td>
        <td><?= $data['nik']; ?></td>
        <td><?= $data['isi_laporan']; ?></td>
        <td><?= $data['tanggapan']; ?></td>
        <td><?= $data['foto']; ?></td>
        <td><?= $data['status']; ?></td>
        <td>
            <a href="proses.php?action=tolak&id=<?= $data['id_pengaduan'] ?>" class="btn btn-danger btn-icon-split" onclick="return confirm('Apakah Anda yakin ingin menolak pengaduan ini?')">
                <span class="icon text-white-50"><i class="fa fa-times"></i></span>
                <span class="text">Tolak</span>
            </a>
        </td>
    </tr>
<?php } ?>
</tbody>

            </table>
        </div>
    </div>
</div>
